import bpy, bmesh
import math
import re
import numpy as np
np.set_printoptions(suppress=True)  # Suprime notación científica en funciones de subdivisión linspace

def segments_to_meshdata(segments):
    """Convierte segmentos en datos de malla (vertices y edges)."""
    segs = segments
    verts = []
    edges = []
    del_offset = 0  # Para mantener el índice correcto al eliminar segmentos de viaje
    for i in range(len(segs)):
        if i >= len(segs)-1:
            if segs[i].style == 'extrude':
                verts.append([segs[i].coords['X'], segs[i].coords['Y'], segs[i].coords['Z']])
            break

        # Inicio de extrusión
        if segs[i].style == 'travel' and segs[i+1].style == 'extrude':
            verts.append([segs[i].coords['X'], segs[i].coords['Y'], segs[i].coords['Z']])
            verts.append([segs[i+1].coords['X'], segs[i+1].coords['Y'], segs[i+1].coords['Z']])
            edges.append([i-del_offset, (i-del_offset)+1])

        # Continúa extruyendo
        if segs[i].style == 'extrude' and segs[i+1].style == 'extrude':
            verts.append([segs[i+1].coords['X'], segs[i+1].coords['Y'], segs[i+1].coords['Z']])
            edges.append([i-del_offset, (i-del_offset)+1])

        # Elimina segmentos de viaje consecutivos
        if segs[i].style == 'travel' and segs[i+1].style == 'travel':
            del_offset +=1

    return verts, edges

def obj_from_pydata(name, verts, edges=None, close=True, collection_name=None):
    """Crea un objeto de malla en Blender a partir de datos de vertices y edges."""
    if edges is None:
        # Unir vertices en una cadena ininterrumpida de edges.
        edges = [[i, i+1] for i in range(len(verts)-1)]
        if close:
            edges.append([len(verts)-1, 0])  # Conectar el último al primero
            
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, edges, [])   
    
    obj = bpy.data.objects.new(name, me)
    
    # Mover a la colección si se especifica
    if collection_name is not None: 
        # Verificar si la colección existe
        collection = bpy.data.collections.get(collection_name)
        if collection: 
            bpy.data.collections[collection_name].objects.link(obj)   
        else:
            collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(collection) 
            bpy.data.collections[collection_name].objects.link(obj) 

class GcodeParser:
    comment = ""  # Global, para acceder en otras clases (ej. RGB)

    def __init__(self):
        self.model = GcodeModel(self)
    
    def parseFile(self, path):
        """Parsea un archivo G-code y construye el modelo."""
        with open(path, 'r') as f:
            self.lineNb = 0
            for line in f:
                self.lineNb +=1
                self.line = line.rstrip()
                self.parseLine()
        return self.model
        
    def parseLine(self):
        """Parsea una línea de G-code."""
        bits = self.line.split(';',1)
        if (len(bits) > 1):
            GcodeParser.comment = bits[1]
        
        command = bits[0].strip()
        comm = command.split(None, 1)
        code = comm[0] if (len(comm)>0) else None
        args = comm[1] if (len(comm)>1) else None
        
        if code:
            if hasattr(self, "parse_"+code):
                getattr(self, "parse_"+code)(args)
            else:
                if code[0] == "T":
                    self.model.toolnumber = int(code[1:])
                else:
                    pass

    def parseArgs(self, args):
        """Parsea los argumentos de una línea de G-code."""
        dic = {}
        if args:
            bits = args.split()
            for bit in bits:
                letter = bit[0]
                try:
                    coord = float(bit[1:])
                except ValueError:
                    coord = 1
                dic[letter] = coord
        return dic
    
    def parse_G1(self, args, type="G1"):
        """Parsea comandos G1 (movimientos controlados)."""
        self.model.do_G1(self.parseArgs(args), type)
    
    def parse_G0(self, args, type="G0"):
        """Parsea comandos G0 (movimientos rápidos)."""
        self.model.do_G1(self.parseArgs(args), type)
    
    def parse_G90(self, args):
        """Configura el modo de posicionamiento absoluto."""
        self.model.setRelative(False)
        
    def parse_G91(self, args):
        """Configura el modo de posicionamiento relativo."""
        self.model.setRelative(True)
        
    def parse_G92(self, args):
        """Setea la posición actual sin mover."""
        self.model.do_G92(self.parseArgs(args))
    
    def warn(self, msg):
        print ("[WARN] Line %d: %s (Text:'%s')" % (self.lineNb, msg, self.line))
        
    def error(self, msg):
        print ("[ERROR] Line %d: %s (Text:'%s')" % (self.lineNb, msg, self.line))
        raise Exception("[ERROR] Line %d: %s (Text:'%s')" % (self.lineNb, msg, self.line))

class GcodeModel:
    def __init__(self, parser):
        self.parser = parser
        self.relative = {
            "X":0.0,
            "Y":0.0,
            "Z":0.0,
            "F":0.0,
            "E":0.0}
        self.offset = {
            "X":0.0,
            "Y":0.0,
            "Z":0.0,
            "E":0.0}
        self.isRelative = False
        self.color = [0,0,0,0,0,0,0,0]  # RGBCMYKW
        self.toolnumber = 0
        self.segments = []
        self.layers = []
    
    def do_G1(self, args, type):
        """Procesa comandos G1/G0."""
        coords = dict(self.relative)
        for axis in args.keys():
            if axis in coords:
                if self.isRelative: 
                    coords[axis] += args[axis]
                else:
                    coords[axis] = args[axis]
            else:
                self.warn("Unknown axis '%s'"%axis)
        
        absolute = {
            "X": self.offset["X"] + coords["X"],
            "Y": self.offset["Y"] + coords["Y"],
            "Z": self.offset["Z"] + coords["Z"],
            "F": coords["F"]
        }
        
        if "E" not in args:
            absolute["E"] = 0
        else:
            absolute["E"] = args["E"]
        
        seg = Segment(
            type,
            absolute,
            self.color,
            self.toolnumber,
            self.parser.lineNb,
            self.parser.line)
        
        if seg.coords['X'] != self.relative['X'] + self.offset["X"] or \
           seg.coords['Y'] != self.relative['Y'] + self.offset["Y"] or \
           seg.coords['Z'] != self.relative['Z'] + self.offset["Z"]:     
            self.addSegment(seg)
        
        self.relative = coords
    
    def do_G92(self, args):
        """Procesa comandos G92 (Set Position)."""
        if not len(args.keys()):
            args = {"X":0.0, "Y":0.0, "Z":0.0}
        for axis in args.keys():
            if axis in self.offset:
                self.offset[axis] += self.relative[axis] - args[axis]
                self.relative[axis] = args[axis]
            else:
                self.warn("Unknown axis '%s'"%axis)
    
    def setRelative(self, isRelative):
        """Configura el modo de posicionamiento."""
        self.isRelative = isRelative
    
    def addSegment(self, segment):
        """Añade un segmento al modelo."""
        self.segments.append(segment)
    
    def classifySegments(self):
        """Clasifica los segmentos en estilos y capas."""
        coords = {
            "X":0.0,
            "Y":0.0,
            "Z":0.0,
            "F":0.0,
            "E":0.0}
        
        currentLayerIdx = 0
        currentLayerZ = 0
        layer = []
        
        for i, seg in enumerate(self.segments):
            style = "travel"
            
            if (
                ((seg.coords["X"] != coords["X"]) or 
                 (seg.coords["Y"] != coords["Y"]) or 
                 (seg.coords["Z"] != coords["Z"])) and 
                (seg.coords["E"] > 0 )
               ):
                style = "extrude"
            
            if i == len(self.segments)-1:
                layer.append(seg)
                currentLayerIdx +=1
                seg.style = style
                seg.layerIdx = currentLayerIdx
                self.layers.append(layer)
                break
            
            if self.segments[i].coords["Z"] != currentLayerZ and self.segments[i+1].coords["E"] > 0:
                self.layers.append(layer)
                layer = []
                currentLayerZ = seg.coords["Z"]
                currentLayerIdx +=1
            
            seg.style = style
            seg.layerIdx = currentLayerIdx
            layer.append(seg)
            coords = seg.coords

    def subdivide(self, subd_threshold):
        """Subdivide segmentos que superen el umbral."""
        subdivided_segs = []
        coords = {
            "X":0.0,
            "Y":0.0,
            "Z":0.0,
            "F":0.0,
            "E":0.0}

        for seg in self.segments:
            d = math.sqrt(
                (seg.coords["X"] - coords["X"])**2 +
                (seg.coords["Y"] - coords["Y"])**2 +
                (seg.coords["Z"] - coords["Z"])**2
            )
            seg.distance = d
            
            if d > subd_threshold:
                subdivs = math.ceil(d / subd_threshold)
                P1 = coords
                P2 = seg.coords

                interp_coords = np.linspace(list(P1.values()), list(P2.values()), num=subdivs, endpoint=True)
                
                for i in range(len(interp_coords)):   
                    new_coords = {
                        "X":interp_coords[i][0], 
                        "Y":interp_coords[i][1], 
                        "Z":interp_coords[i][2], 
                        "F":seg.coords["F"]
                    }
                    if seg.coords["E"] > 0:
                        new_coords["E"] = round(seg.coords["E"] / (subdivs-1), 5)
                    else:
                        new_coords["E"] = 0
                    
                    if new_coords['X'] != coords['X'] or \
                       new_coords['Y'] != coords['Y'] or \
                       new_coords['Z'] != coords['Z']:
                        
                        new_seg = Segment(seg.type, new_coords, seg.color, seg.toolnumber, seg.lineNb, seg.line)
                        new_seg.layerIdx = seg.layerIdx
                        new_seg.style = seg.style
                        subdivided_segs.append(new_seg)
            else:
                subdivided_segs.append(seg) 

            coords = seg.coords 

        self.segments = subdivided_segs

    def create_continuous_curve(self):
        """Crea una curva continua a partir de todos los segmentos."""
        verts = []
        for seg in self.segments:
            verts.append((seg.coords['X'], seg.coords['Y'], seg.coords['Z']))
        
        # Crear los edges para una curva continua
        edges = [(i, i + 1) for i in range(len(verts) - 1)]

        # Crear la curva
        curve_data = bpy.data.curves.new('GCodeContinuousPath', type='CURVE')
        curve_data.dimensions = '3D'
        polyline = curve_data.splines.new('POLY')
        polyline.points.add(len(verts) - 1)
        
        for i, vert in enumerate(verts):
            polyline.points[i].co = (vert[0], vert[1], vert[2], 1)

        curve_obj = bpy.data.objects.new('GCodeContinuousCurve', curve_data)
        bpy.context.collection.objects.link(curve_obj)
        return curve_obj

    def draw(self, split_layers=False, continuous=False):
        if split_layers:
            i = 0
            for layer in self.layers:
                verts, edges = segments_to_meshdata(layer)
                if len(verts) > 0:
                    obj_from_pydata(str(i), verts, edges, close=False, collection_name="Layers")
                    i +=1
        elif continuous:
            self.create_continuous_curve()
        else:
            verts, edges = segments_to_meshdata(self.segments)
            obj_from_pydata("Gcode", verts, edges, close=False, collection_name="Layers")

class Segment:
    def __init__(self, type, coords, color, toolnumber, lineNb, line):
        self.type = type
        self.coords = coords
        self.color = color
        self.toolnumber = toolnumber
        self.lineNb = lineNb
        self.line = line
        self.style = None
        self.layerIdx = None
        self.distance = None

    def __str__(self):
        return " <coords=%s, lineNb=%d, style=%s, layerIdx=%d, color=%s>" % (
            str(self.coords), 
            self.lineNb, 
            self.style, 
            self.layerIdx, 
            str(self.color)
        )
