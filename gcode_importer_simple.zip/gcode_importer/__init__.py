bl_info = {
    "name": "Importador de G-code para Timelapse de Impresión 3D",
    "blender": (4, 2, 0),
    "category": "Import-Export",
    "author": "Tu Nombre",
    "version": (1, 0),
    "description": "Importa archivos G-code y crea animaciones de filamento para timelapses de impresión 3D",
}

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    PointerProperty,
    FloatProperty,
    EnumProperty,
    IntProperty,  # Asegúrate de importar IntProperty
)
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
)
from bpy_extras.io_utils import ImportHelper

from . import parser
import math
import numpy as np

# Definición de las propiedades del add-on
class ImportGcodeSettings(PropertyGroup):
    split_layers: BoolProperty(
        name="Separar Capas",
        description="Guardar cada capa como un objeto individual en una colección",
        default=True
    )

    subdivide: BoolProperty(
        name="Subdividir",
        description="Subdividir segmentos de G-code que superen el tamaño de segmento especificado",
        default=False
    )

    max_segment_size: FloatProperty(
        name="Longitud Máxima de Segmento",
        description="Solo se subdividen segmentos mayores a este valor",
        default=1.0,
        min=0.1,
        max=999.0
    )

    create_continuous: BoolProperty(
        name="Crear Curva Continua",
        description="Crear una única curva continua en lugar de objetos separados por capas",
        default=True
    )

    filament_radius: FloatProperty(
        name="Radio del Filamento",
        description="Radio del objeto que representará el filamento",
        default=0.1,
        min=0.01,
        max=10.0
    )

    filament_speed: FloatProperty(
        name="Velocidad del Filamento",
        description="Velocidad de animación del filamento (unidades por frame)",
        default=1.0,
        min=0.1,
        max=10.0
    )

    bevel_depth: FloatProperty(
        name="Profundidad del Bevel",
        description="Profundidad del bevel aplicado al objeto del filamento",
        default=0.02,
        min=0.0,
        max=1.0
    )

    bevel_resolution: IntProperty(
        name="Resolución del Bevel",
        description="Número de segmentos en el bevel",
        default=2,
        min=0,
        max=10
    )

    filament_object: EnumProperty(
        name="Objeto de Filamento",
        description="Objeto a utilizar para representar el filamento",
        items=[
            ('CYLINDER', "Cilindro", "Usar un cilindro como filamento"),
            ('SPHERE', "Esfera", "Usar una esfera como filamento"),
            ('CUSTOM', "Personalizado", "Usar un objeto personalizado")
        ],
        default='CYLINDER'
    )

# Panel de Importación de G-code
class OBJECT_PT_CustomPanel(Panel):
    bl_label = "Importador de G-code"
    bl_idname = "OBJECT_PT_custom_panel"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "Gcode-Import"
    bl_context = "objectmode"   

    @classmethod
    def poll(cls, context):
        return context.mode in {'OBJECT', 'EDIT_MESH'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        mytool = scene.gcode_importer_settings

        layout.prop(mytool, "split_layers")
        layout.prop(mytool, "subdivide")

        row = layout.row()
        row.prop(mytool, "max_segment_size")
        row.enabled = mytool.subdivide

        layout.prop(mytool, "create_continuous")
        layout.prop(mytool, "filament_object")
        layout.prop(mytool, "filament_radius")
        layout.prop(mytool, "filament_speed")
        layout.prop(mytool, "bevel_depth")
        layout.prop(mytool, "bevel_resolution")

        layout.separator()

        layout.operator("wm.gcode_import", text="Importar G-code")

# Operador de Importación de G-code
class WM_OT_gcode_import(Operator, ImportHelper):
    """Importar G-code y crear animaciones de filamento"""
    bl_idname = "wm.gcode_import"
    bl_label = "Importar G-code"
    bl_options = {'REGISTER', 'UNDO'}
    
    # ImportHelper mixin class uses this
    filename_ext = ".gcode;*.txt"
    
    filter_glob: StringProperty(
        default="*.gcode;*.txt",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        return import_gcode(context, self.filepath)

# Función para importar G-code y crear la animación
def import_gcode(context, filepath):
    print("Ejecutando importación de G-code...")

    scene = context.scene
    mytool = scene.gcode_importer_settings
    import time
    then = time.time()

    parse = parser.GcodeParser()
    model = parse.parseFile(filepath)
    
    if mytool.subdivide:
        model.subdivide(mytool.max_segment_size)
    model.classifySegments()
    
    if mytool.create_continuous:
        curve_obj = model.create_continuous_curve()
    else:
        model.draw(split_layers=mytool.split_layers, continuous=False)
    
    if mytool.create_continuous:
        # Crear el objeto del filamento
        filament = create_filament_object(mytool)
        
        # Configurar Geometry Nodes para la animación
        setup_geometry_nodes(filament, curve_obj, mytool)
    
    now = time.time()
    print("Importación completada en", now - then, "segundos.")

    return {'FINISHED'}

# Función para crear el objeto del filamento
def create_filament_object(mytool):
    if mytool.filament_object == 'CYLINDER':
        bpy.ops.mesh.primitive_cylinder_add(radius=mytool.filament_radius, depth=1.0, location=(0,0,0))
    elif mytool.filament_object == 'SPHERE':
        bpy.ops.mesh.primitive_uv_sphere_add(radius=mytool.filament_radius, location=(0,0,0))
    elif mytool.filament_object == 'CUSTOM':
        bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0,0,0))
        filament = bpy.context.active_object
        filament.name = "Filament_Custom"
        return filament
    
    filament = bpy.context.active_object
    filament.name = "Filament"
    
    # Aplicar bevel
    bpy.ops.object.modifier_add(type='BEVEL')
    bevel = filament.modifiers["Bevel"]
    bevel.width = mytool.bevel_depth
    bevel.segments = mytool.bevel_resolution
    
    bpy.ops.object.shade_smooth()
    
    return filament

# Función para configurar Geometry Nodes
def setup_geometry_nodes(filament, curve_obj, mytool):
    # Crear un nuevo nodo de Geometry Nodes
    gn = filament.modifiers.new(type="NODES", name="GeometryNodes")
    node_group = bpy.data.node_groups.new(type="GeometryNodeTree", name="FilamentAnimation")
    gn.node_group = node_group
    
    nodes = node_group.nodes
    links = node_group.links
    
    # Limpiar nodos por defecto
    for node in nodes:
        nodes.remove(node)
    
    # Crear nodos necesarios
    input_node = nodes.new(type='NodeGroupInput')
    input_node.location = (-600, 0)
    
    output_node = nodes.new(type='NodeGroupOutput')
    output_node.location = (600, 0)
    
    # Object Info node for the curve
    object_info = nodes.new(type='GeometryNodeObjectInfo')
    object_info.location = (-400, 200)
    object_info.inputs['Object'].default_value = curve_obj
    
    # Sample Nearest node
    sample_nearest = nodes.new(type='GeometryNodeSampleNearest')
    sample_nearest.location = (-200, 200)
    links.new(object_info.outputs['Geometry'], sample_nearest.inputs['Geometry'])
    
    # Value node for animation factor
    value_node = nodes.new(type='ShaderNodeValue')
    value_node.location = (-600, 200)
    
    # Conectar el nodo Value al Sample Nearest
    links.new(value_node.outputs['Value'], sample_nearest.inputs['Factor'])
    
    # Set Position node
    set_position = nodes.new(type='GeometryNodeSetPosition')
    set_position.location = (0, 200)
    links.new(sample_nearest.outputs['Position'], set_position.inputs['Position'])
    links.new(input_node.outputs['Geometry'], set_position.inputs['Geometry'])
    
    # Conectar Set Position al Output
    links.new(set_position.outputs['Geometry'], output_node.inputs['Geometry'])
    
    # Asignar el nodo Group Input y Output
    node_group.inputs.new('NodeSocketGeometry', "Geometry")
    node_group.outputs.new('NodeSocketGeometry', "Geometry")
    
    # Insertar keyframes en el nodo Value para animar el factor
    value_node.outputs['Value'].default_value = 0.0
    value_node.outputs['Value'].keyframe_insert(data_path="default_value", frame=1)
    value_node.outputs['Value'].default_value = 1.0
    value_node.outputs['Value'].keyframe_insert(data_path="default_value", frame=250)
    
    # Configurar el constraint de Follow Path
    constraint = filament.constraints.new(type='FOLLOW_PATH')
    constraint.target = curve_obj
    constraint.use_curve_follow = True
    
    # Animar el factor de evaluación del constraint
    constraint.offset_factor = 0
    constraint.keyframe_insert(data_path="offset_factor", frame=1)
    constraint.offset_factor = 1
    constraint.keyframe_insert(data_path="offset_factor", frame=250)
    
    # Configurar la línea de tiempo
    bpy.context.scene.frame_start = 1
    bpy.context.scene.frame_end = 250

# Registro de clases
classes = (
    ImportGcodeSettings,
    OBJECT_PT_CustomPanel,
    WM_OT_gcode_import,
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.gcode_importer_settings = PointerProperty(type=ImportGcodeSettings)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.gcode_importer_settings

if __name__ == "__main__":
    register()
